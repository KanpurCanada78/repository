package com.constant;

public final class Constants {

	public static final String responseTypeBorderfree= "Borderfree" ;
	public static final String responseSubTypeBorderfree= "BF - Accepted Payment" ;
	public static final String brandName="Bergdorf Goodman";
	
	
}
